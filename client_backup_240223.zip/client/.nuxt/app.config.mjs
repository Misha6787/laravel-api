
import { defuFn } from 'C:/OpenServer/domains/laravel-nuxt/client/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
