export default defineAppConfig({
    title: 'Hello Nuxt',
    theme: {
        dark: false,
        colors: {
            primary: '#ff0000'
        }
    }
})
