// https://v3.nuxtjs.org/api/configuration/nuxt.config



export default {
    // routeRules: undefined,

    app: {
        pageTransition: { name: 'page' },
        layoutTransition: { name: 'layout' },
        head: {
            charset: 'utf-8',
            viewport: 'width=device-width, initial-scale=1',
            title: 'My Library',
            meta: [
                // <meta name="description" content="My amazing site">
                { name: 'description', content: 'My amazing site' }
            ]
        }
    },

    publicRuntimeConfig: {
        API_BASE_URL: process.env.API_BASE_URL
    },

    // dev: process.env.NODE_ENV !== 'production',

    buildModules: [
        '@nuxtjs/tailwindcss',
        '@nuxtjs/color-mode'
    ],

    modules: [
        // '@nuxtjs/auth-next'
    ],

    // auth: {
    //     strategies: {
    //         laravelSanctum: {
    //             provider: 'laravel/sanctum',
    //             url: '<laravel url>'
    //         },
    //     }
    // },

    // router: {
    //     middleware: ['auth']
    // },

    build: {
        transpile: ["class-validator"]
    },

    proxy: {
        '/laravel': {
            target: 'http://laravel-nuxt/api/v1/',
            pathRewrite: { '^/laravel': '/' }
        }
    },

    auth: {
        strategies: {
            laravelSanctum: {
                provider: 'laravel/sanctum',
                url: '<laravel url>'
            }
        }
    },

    // vite: {
    //     optimizeDeps: {
    //         exclude: ['class-validator']
    //     }
    // },

    css: [
        '~/assets/css/custom.css',
        '~/assets/css/tailwind.css'
    ],
    tailwindcss: {
        cssPath: '~/assets/css/tailwind.css',
        configPath: 'tailwind.config.js',
        exposeConfig: false,
        injectPosition: 0,
        viewer: true
    },
    colorMode: {
        classSuffix: ''
    }
}
