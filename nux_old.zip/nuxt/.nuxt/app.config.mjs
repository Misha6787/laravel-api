
import { defuFn } from 'C:/OpenServer/domains/laravel-nuxt/nuxt/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}

import cfg0 from "C:/OpenServer/domains/laravel-nuxt/nuxt/app.config.ts"

export default defuFn(cfg0, inlineConfig)
