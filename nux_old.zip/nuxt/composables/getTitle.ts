export default (title:string) => {
    return ref(title)
}